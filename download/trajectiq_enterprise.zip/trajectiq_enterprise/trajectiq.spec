# -*- mode: python ; coding: utf-8 -*-
"""
TrajectIQ Enterprise PyInstaller Spec File
==========================================
Builds standalone Windows executable with all dependencies.
"""

import os
import sys
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# Project root
project_root = os.path.dirname(os.path.abspath(SPEC))

# Collect all hidden imports
hidden_imports = [
    # Core modules
    'src.core.config',
    'src.core.database',
    'src.core.logger',
    'src.security.rbac',
    'src.security.license',
    'src.modules.scoring_engine',
    'src.modules.bias_detection',
    # External dependencies
    'cryptography',
    'cryptography.fernet',
    'cryptography.hazmat.primitives',
    'cryptography.hazmat.primitives.asymmetric',
    'cryptography.hazmat.primitives.asymmetric.rsa',
    'cryptography.hazmat.primitives.asymmetric.padding',
    'cryptography.hazmat.primitives.hashes',
    'cryptography.hazmat.backends',
    'cryptography.hazmat.backends.default_backend',
    'bcrypt',
    'sqlite3',
    'json',
    'hashlib',
    'uuid',
    'secrets',
    'datetime',
    'pathlib',
    'typing',
    'dataclasses',
    'enum',
    'abc',
    'collections',
    'statistics',
    'threading',
    'contextlib',
    # PyQt5
    'PyQt5',
    'PyQt5.QtCore',
    'PyQt5.QtGui',
    'PyQt5.QtWidgets',
    'PyQt5.sip',
]

# Collect data files
datas = [
    # Include assets
    (os.path.join(project_root, 'assets'), 'assets'),
    # Include default config
    (os.path.join(project_root, 'config'), 'config'),
]

# Analysis
a = Analysis(
    [os.path.join(project_root, 'src', 'main.py')],
    pathex=[project_root],
    binaries=[],
    datas=datas,
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'tkinter',
        'matplotlib',
        'numpy',
        'pandas',
        'scipy',
        'PIL',
        'cv2',
        'IPython',
        'jupyter',
        'notebook',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# PYZ bundle
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# EXE
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='TrajectIQ',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # GUI application, no console window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=os.path.join(project_root, 'assets', 'icon.ico') if os.path.exists(os.path.join(project_root, 'assets', 'icon.ico')) else None,
    version=os.path.join(project_root, 'version_info.txt') if os.path.exists(os.path.join(project_root, 'version_info.txt')) else None,
)
