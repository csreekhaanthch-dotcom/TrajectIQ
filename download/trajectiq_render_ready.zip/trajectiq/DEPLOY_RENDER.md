# Deploy TrajectIQ to Render

## Quick Start

1. **Fork or Clone** this repository to your GitHub account
2. **Create a Render Account** at https://render.com (use GitHub SSO)
3. **Deploy using Blueprint** or manually create services

## Blueprint Deployment (Recommended)

1. Log in to Render Dashboard
2. Click **New** → **Blueprint**
3. Select your repository
4. Render automatically detects `render.yaml`
5. Click **Apply**

Your services will be live in ~5 minutes!

## Manual Deployment

### Backend API (Python FastAPI)

```yaml
Service Type: Web Service
Name: trajectiq-api
Environment: Python 3
Region: Oregon
Branch: main
Root Directory: backend
Build Command: pip install -r requirements-render.txt
Start Command: uvicorn server:app --host 0.0.0.0 --port $PORT
Plan: Free
```

### Frontend Dashboard (Next.js)

```yaml
Service Type: Web Service
Name: trajectiq-dashboard
Environment: Node
Region: Oregon
Branch: main
Root Directory: frontend
Build Command: npm install && npm run build
Start Command: npm start
Plan: Free
Environment Variables:
  NEXT_PUBLIC_API_URL: https://trajectiq-api.onrender.com
```

## Environment Variables

### Backend
| Variable | Value |
|----------|-------|
| PYTHON_VERSION | 3.11.0 |
| ENVIRONMENT | production |

### Frontend
| Variable | Value |
|----------|-------|
| NODE_VERSION | 18.0.0 |
| NEXT_PUBLIC_API_URL | https://trajectiq-api.onrender.com |

## Verify Deployment

1. Check backend health: `https://trajectiq-api.onrender.com/health`
2. Open frontend: `https://trajectiq-dashboard.onrender.com`
3. Run a test evaluation

## Free Tier Notes

- Services spin down after 15 minutes of inactivity
- First request after spin-down takes ~30 seconds
- 750 free hours per month per service

## Architecture

```
┌─────────────────┐     ┌─────────────────┐
│   Frontend      │────▶│    Backend      │
│   (Next.js)     │     │   (FastAPI)     │
│   Port: 3000    │     │   Port: 8000    │
└─────────────────┘     └─────────────────┘
        │                       │
        ▼                       ▼
┌─────────────────┐     ┌─────────────────┐
│   Render CDN    │     │  Python Modules │
│                 │     │  - Resume Parser│
│                 │     │  - Skill Eval   │
│                 │     │  - Impact Score │
│                 │     │  - Trajectory   │
│                 │     │  - AI Detector  │
│                 │     │  - Scoring      │
└─────────────────┘     └─────────────────┘
```

## Troubleshooting

### Build Fails
- Check build logs in Render dashboard
- Verify all dependencies are listed in requirements-render.txt

### Service Unhealthy
- Check health endpoint: `/health`
- Review application logs

### CORS Errors
- Already configured in `server.py` with `allow_origins=["*"]`
- For production, restrict to your frontend domain

## Support

- Render Docs: https://render.com/docs
- GitHub Issues: https://github.com/csreekhaanthch-dotcom/TrajectIQ/issues
