# TrajectIQ Render Deployment Guide

This guide provides step-by-step instructions for deploying TrajectIQ to Render.

## Prerequisites

1. A GitHub account with the TrajectIQ repository
2. A Render account (free tier available at https://render.com)

## Step 1: Push Code to GitHub

If you haven't already pushed the latest code to GitHub:

```bash
cd /path/to/trajectiq
git add -A
git commit -m "Update for Render deployment"
git push origin main
```

## Step 2: Create Render Account

1. Go to https://render.com
2. Sign up using your GitHub account (recommended for easy integration)
3. Verify your email address

## Step 3: Deploy Backend API Service

### Option A: Using render.yaml (Blueprint)

1. In Render dashboard, click **"New"** → **" Blueprint"**
2. Connect your GitHub repository: `csreekhaanthch-dotcom/TrajectIQ`
3. Render will detect the `render.yaml` file automatically
4. Review the services and click **"Apply"**

### Option B: Manual Setup

1. In Render dashboard, click **"New"** → **" Web Service"**
2. Connect your GitHub repository
3. Configure the service:

| Setting | Value |
|---------|-------|
| Name | `trajectiq-api` |
| Region | Oregon (or closest) |
| Branch | main |
| Root Directory | `backend` |
| Runtime | Python 3 |
| Build Command | `pip install -r requirements-render.txt` |
| Start Command | `uvicorn server:app --host 0.0.0.0 --port $PORT` |

4. Add Environment Variables:

| Key | Value |
|-----|-------|
| `PYTHON_VERSION` | `3.11.0` |
| `ENVIRONMENT` | `production` |

5. Select **Free** plan
6. Click **"Create Web Service"**

## Step 4: Deploy Frontend Dashboard

1. In Render dashboard, click **"New"** → **" Web Service"**
2. Select the same repository
3. Configure the service:

| Setting | Value |
|---------|-------|
| Name | `trajectiq-dashboard` |
| Region | Oregon (or closest) |
| Branch | main |
| Root Directory | `frontend` |
| Runtime | Node |
| Build Command | `npm install && npm run build` |
| Start Command | `npm start` |

4. Add Environment Variables:

| Key | Value |
|-----|-------|
| `NODE_VERSION` | `18.0.0` |
| `NEXT_PUBLIC_API_URL` | `https://trajectiq-api.onrender.com` |

5. Select **Free** plan
6. Click **"Create Web Service"**

## Step 5: Verify Deployment

### Backend API Health Check

1. Wait for the backend service to finish deploying (usually 3-5 minutes)
2. Visit: `https://trajectiq-api.onrender.com/health`
3. You should see: `{"status": "healthy"}`

### Frontend Dashboard

1. Wait for the frontend service to finish deploying
2. Visit: `https://trajectiq-dashboard.onrender.com`
3. You should see the TrajectIQ dashboard

## Step 6: Test the Full Pipeline

1. Open the frontend dashboard
2. Paste a resume in the Resume Content field
3. Paste job requirements in JSON format
4. Click "Run Evaluation"
5. View the results

## Troubleshooting

### Backend Service Won't Start

- Check the logs in Render dashboard
- Ensure all dependencies are in `requirements-render.txt`
- Verify the start command is correct

### Frontend Can't Connect to Backend

- Verify the `NEXT_PUBLIC_API_URL` environment variable is set correctly
- Check that the backend service is running
- Ensure CORS is configured (already set in server.py)

### Free Tier Limitations

Render's free tier has some limitations:
- Services spin down after inactivity (first request takes ~30 seconds)
- Limited compute resources
- 750 hours/month of free runtime

## Service URLs

After deployment, your services will be available at:

- **Backend API**: https://trajectiq-api.onrender.com
- **Frontend Dashboard**: https://trajectiq-dashboard.onrender.com

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | API info |
| `/health` | GET | Health check |
| `/api/evaluate` | POST | Full evaluation pipeline |
| `/api/evaluate/skills` | POST | Skill evaluation only |
| `/api/evaluate/impact` | POST | Impact scoring only |
| `/api/evaluate/trajectory` | POST | Trajectory analysis only |
| `/api/evaluate/ai-detect` | POST | AI detection only |
| `/api/stats` | GET | Dashboard statistics |
| `/api/candidates` | GET | List candidates |
| `/api/jobs` | GET | List jobs |

## Next Steps

1. **Custom Domain**: Add a custom domain in Render dashboard
2. **Monitoring**: Set up Render's built-in monitoring and alerts
3. **Scaling**: Upgrade to paid plans for better performance
4. **Database**: Add PostgreSQL for persistent storage

---

For more information, visit the [Render Documentation](https://render.com/docs).
